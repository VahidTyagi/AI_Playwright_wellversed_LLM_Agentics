(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_5M5cecLWGDD5WvtEJ7vkzEVoN36nrUbyuQC6E7i8OWV'] = {
    config: {"analytics": {"endpoint": "/i/v0/e/"}, "autocaptureExceptions": false, "autocapture_opt_out": false, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "conversations": false, "defaultIdentifiedOnly": true, "elementsChainAsString": true, "errorTracking": {"autocaptureExceptions": false, "suppressionRules": []}, "hasFeatureFlags": false, "heatmaps": false, "logs": {"captureConsoleLogs": false}, "productTours": false, "sessionRecording": false, "supportedCompression": ["gzip", "gzip-js"], "surveys": false, "token": "phc_5M5cecLWGDD5WvtEJ7vkzEVoN36nrUbyuQC6E7i8OWV"},
    siteApps: []
  }
})();